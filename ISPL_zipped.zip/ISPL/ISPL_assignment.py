import sqlite3
import random

# Define SQL commands for creating the tables
create_calls = '''CREATE TABLE IF NOT EXISTS calls (
                        call_id INTEGER,
                        caller_id INTEGER PRIMARY KEY,
                        receiver_id INTEGER,
                        duration INTEGER,
                        month TEXT,
                        frequency INTEGER,
                        FOREIGN KEY (caller_id) REFERENCES people(person_id),
                        FOREIGN KEY (receiver_id) REFERENCES people(person_id)                        
                    )'''

create_messages = '''CREATE TABLE IF NOT EXISTS messages (
                        message_id INTEGER,
                        sender_id INTEGER PRIMARY KEY,
                        receiver_id INTEGER,
                        content VARCHAR(100),
                        month TEXT,
                        frequency INTEGER,
                        FOREIGN KEY (sender_id) REFERENCES people(person_id),
                        FOREIGN KEY (receiver_id) REFERENCES people(person_id) 
                        )'''

create_people_asked_direction = '''CREATE TABLE IF NOT EXISTS people_asked_direction (
                            direction_id INTEGER,
                            month TEXT,
                            frequency INTEGER,
                            person_id INTEGER PRIMARY KEY
                        )'''

create_website_views = '''CREATE TABLE IF NOT EXISTS website_views (
                            visit_id INTEGER,
                            visitor_id INTEGER PRIMARY KEY,
                            month TEXT,
                            frequency INTEGER,
                            FOREIGN KEY (visitor_id) REFERENCES people(person_id)
                        )'''

create_profile_views = '''CREATE TABLE IF NOT EXISTS profile_views (
                            view_id INTEGER,
                            viewer_id INTEGER PRIMARY KEY,
                            month TEXT,
                            frequency INTEGER,
                            FOREIGN KEY (viewer_id) REFERENCES people(person_id)
                        )'''

create_appearance = '''CREATE TABLE IF NOT EXISTS appearence (
                            appearence_id INTEGER,
                            search_term TEXT,
                            profile_id INTEGER PRIMARY KEY,
                            month TEXT,
                            frequency INTEGER,
                            FOREIGN KEY (profile_id) REFERENCES people(person_id)
                        )'''


# Define SQL commands for inserting sample data into the tables
# Insert sample data into the 'calls' table
insert_into_Calls = '''INSERT INTO calls (call_id, caller_id, receiver_id, duration, month, frequency) VALUES
                       (1, 112, 115, 5, 'JANUARY', 10),
                       (2, 115, 112, 18, 'FEBRUARY', 12),
                       (3, 513, 113, 7, 'DECEMBER', 30),
                       (4, 412, 513, 7, 'JANUARY', 45),
                       (5, 113, 112, 8, 'JANUARY', 4);
                    '''



#Insert sample data into the 'messages' table
insert_into_messages = '''INSERT INTO messages (message_id, sender_id, receiver_id, content, month, frequency) VALUES
                          (1, 112, 513, 'Hello!', 'JANUARY', 10),
                          (2, 115, 513, 'Hi there!', 'DECEMBER', 20),
                          (3, 113, 112, 'Hope you are doing well', 'JANUARY', 5),
                          (4, 413, 115, 'Accept connection', 'DECEMBER', 5),
                          (5, 116, 513, 'Hi Sir/Mam', 'JANUARY', 20);
                        '''

# Insert sample data into the 'people_asked_direction' table
insert_into_people_asked_direction = '''INSERT INTO people_asked_direction (direction_id, person_id, month, frequency) VALUES
                                        (1, 112, 'JANUARY', 25),
                                        (2, 115, 'DECEMBER', 40),
                                        (3, 113, 'JANUARY', 250),
                                        (4, 412, 'DECEMBER', 50),
                                        (5, 405, 'JANUARY', 500);
                                    '''

#Insert sample data into the 'website_views' table
insert_into_website_views = '''INSERT INTO website_views (visit_id, visitor_id, month, frequency) VALUES
                               (1, 112, 'JANUARY', 200),
                               (2, 115, 'DECEMBER', 50),
                               (3, 405, 'DECEMBER', 150),
                               (4, 413, 'JANUARY', 500),
                               (5, 513, 'JANUARY', 150);
                            '''

# Insert sample data into the 'profile_views' table
insert_into_profile_views = '''INSERT INTO profile_views (view_id, viewer_id, month, frequency) VALUES
                               (1, 115, 'JANUARY', 150),
                               (2, 513, 'DECEMBER', 50),
                               (3, 413, 'JANUARY', 25),
                               (4, 112, 'DECEMBER', 51),
                               (5, 514, 'JANUARY', 100);
                            '''

#Insert sample data into the 'searches_appearance' table
insert_into_appearence = '''INSERT INTO appearence (appearence_id, search_term, profile_id, month, frequency) VALUES
                            (1, 'Restaurant', 112, 'JANUARY', 115),
                            (2, 'Gym', 113, 'DECEMBER', 50),
                            (3, 'Hotel', 114, 'DECEMBER', 15),
                            (4, 'Mall', 115, 'JANUARY', 150),
                            (5, 'Theatre', 513, 'JANUARY', 15);
                        '''


class DatabaseReportGenerator:
    def __init__(self):
        # Establish a database connection using the provided parameters
        with sqlite3.connect('statistics.db') as conn:
        # Create the sales table
            conn.execute(create_calls)

            # Create the products table
            conn.execute(create_messages)

            # Create the customers table
            conn.execute(create_people_asked_direction)

            conn.execute(create_website_views)

            conn.execute(create_profile_views)

            conn.execute(create_appearance)


            # Insert sample data into the calls table
            conn.execute(insert_into_Calls)

            # Insert sample data into the messagess table
            conn.execute(insert_into_messages)

            # Insert sample data into the directiom table
            conn.execute(insert_into_people_asked_direction)

            # Insert sample data into the websit table
            conn.execute(insert_into_website_views)

            # Insert sample data into the profile table
            conn.execute(insert_into_profile_views)

            # Insert sample data into the apperance table
            conn.execute(insert_into_appearence)

            
            # Commit the changes
            conn.commit()
            self.cursor = conn.cursor()
            print("Database successfully created!")

    def fetch_calls_data(self):
        # Fetch calls data for the specified month
        query = "SELECT * FROM calls;"
        self.cursor.execute(query)
        calls_data = self.cursor.fetchall()
        return calls_data



    '''def fetch_messages_data(self, month):
        # Fetch messages data for the specified month

    def fetch_direction_requests_data(self, month):
        # Fetch direction requests data for the specified month

    def fetch_website_visits_data(self, month):
        # Fetch website visits data for the specified month

    def fetch_profile_views_data(self, month):
        # Fetch profile views data for the specified month

    def fetch_search_appearances_data(self, month):
        # Fetch search appearances data for the specified month

    def generate_report(self, month):
        # Call the above functions to fetch data
        # Process and consolidate the data into a multi-dimensional associated array
        # Return the final report data structure

# Main function
def main():
    # Create an instance of the DatabaseReportGenerator class
    report_generator = DatabaseReportGenerator(db_connection_params)
    # Call the generate_report method for the desired month
    report = report_generator.generate_report(month)
    # Output the report
    print(report)

# Execute the main function
main()'''

report = DatabaseReportGenerator()
report
