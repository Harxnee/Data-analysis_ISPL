from pathlib import Path
import sqlite3

import pandas as pd  # pip install pandas
import plotly.express as px  # pip install plotly-express kaleido
from fpdf import FPDF  # pip install fpdf


# Define the paths
current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()
database_path = current_dir / "statistics.db"


# Create the output directory and its parent directory if they do not exist
output_dir.mkdir(parents=True, exist_ok=True)

# Create a connection to the database
conn = sqlite3.connect(database_path)

def find_performance():
    query1 = '''
    SELECT SUM(frequency) FROM calls WHERE month='JANUARY';
    '''
    val1 = pd.read_sql_query(query1, conn)
    print('calls in January: ' ,val1)

    query2 = '''
    SELECT SUM(frequency) FROM messages WHERE month='JANUARY';
    '''
    val2 = pd.read_sql_query(query2, conn)
    print('messages in January: ' ,val2)

    query3 = '''
    SELECT SUM(frequency) FROM people_asked_direction WHERE month='JANUARY';
    '''
    val3 = pd.read_sql_query(query3, conn)
    print('Directions asked for in January: ' ,val3)

    query4 = '''
    SELECT SUM(frequency) FROM website_views WHERE month='JANUARY';
    '''
    val4 = pd.read_sql_query(query4, conn)
    print('Website views in January: ' ,val4)

    query5 = '''
    SELECT SUM(frequency) FROM profile_views WHERE month='JANUARY';
    '''
    val5 = pd.read_sql_query(query5, conn)
    print('calls in January: ' ,val5)

    query6 = '''
    SELECT SUM(frequency) FROM appearence WHERE month='JANUARY';
    '''
    val6 = pd.read_sql_query(query6, conn)
    print('calls in January: ' ,val6)


def find_search_term():
    query = '''
    SELECT search_term, frequency 
    FROM appearence 
    WHERE month = 'JANUARY' 
    ORDER BY frequency DESC
    LIMIT 3;
    '''
    val = pd.read_sql_query(query, conn)
    print('Most frequent search terms: ' ,val)




find_performance()
find_search_term()